import 'package:flutter/material.dart';

const ostrovBlue = Color(0xFF168FCB);
const ostrovIce = Color(0xFFEAF7FD);
