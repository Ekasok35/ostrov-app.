import 'package:flutter/material.dart';
import 'screens/booking_page.dart';
import 'theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const OstrovApp());
}

class OstrovApp extends StatelessWidget {
  const OstrovApp({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = ColorScheme.fromSeed(
      seedColor: ostrovBlue,
      primary: ostrovBlue,
      surface: Colors.white,
    );
    return MaterialApp(
      title: 'OSTROV',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: scheme,
        scaffoldBackgroundColor: ostrovIce,
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: ostrovBlue,
          elevation: 0,
          centerTitle: false,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFE1EDF3)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: ostrovBlue, width: 1.5),
          ),
        ),
      ),
      home: const BookingPage(),
    );
  }
}
